#version 460

layout(location = 0) in vec3 faceColor;
layout(location = 0) out vec4 outColor;

void main() {
    outColor = vec4(faceColor, 1.0);
}
